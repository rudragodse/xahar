package com.example.rudra.xahar;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Parcel;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;

public class MainActivity extends AppCompatActivity {

    EditText emailEditText;
    EditText passwordEditText;
    Button signInButton;
    TextView orTextView;
    ProgressDialog progressDialog;

    FirebaseAuth firebaseAuth;

    public void LogIn(View view)
    {
        Intent intent=new Intent(getApplicationContext(),LogInActivity.class);
        startActivity(intent);
    }


    public void Register(View view)
    {
        String email=emailEditText.getText().toString().trim();
        String password=passwordEditText.getText().toString().trim();

        if (TextUtils.isEmpty(email))
        {

            Toast.makeText(this, "email address is too short", Toast.LENGTH_SHORT).show();

        }
        if (TextUtils.isEmpty(password))
        {
            Toast.makeText(this, "Please enter a valid password", Toast.LENGTH_SHORT).show();
        }

        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Registering user...");
        progressDialog.show();

        firebaseAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful())
                {
                    Toast.makeText(MainActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firebaseAuth=FirebaseAuth.getInstance();

        emailEditText=(EditText)findViewById(R.id.EmailEditText);

        passwordEditText=(EditText)findViewById(R.id.passwordEditText);

        signInButton =(Button)findViewById(R.id.signinButton);

        orTextView=(TextView)findViewById(R.id.ortextView);

        String user=firebaseAuth.getCurrentUser().toString();

        if (!TextUtils.isEmpty(user))
        {
            Log.i("User Info:",firebaseAuth.getCurrentUser().getEmail().toString());
        }










    }
}
