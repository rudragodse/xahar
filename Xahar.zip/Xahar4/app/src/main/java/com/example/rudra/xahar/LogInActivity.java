package com.example.rudra.xahar;

import android.content.Intent;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class LogInActivity extends AppCompatActivity {

    private FirebaseAuth.AuthStateListener mauth;

    public void SlideMenu(View view)
    {

        mauth= new FirebaseAuth.AuthStateListener() {
             @Override
             public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                 if (firebaseAuth.getCurrentUser()==null)
                 {
                     Toast.makeText(LogInActivity.this, "Log In successful"+ "Welcome " +firebaseAuth.getCurrentUser().getEmail().toString(), Toast.LENGTH_SHORT).show();
                 }
                 else
                 {
                     Toast.makeText(LogInActivity.this, "User" + firebaseAuth.getCurrentUser().getEmail()+ "is logged in", Toast.LENGTH_SHORT).show();
                 }

             }
         };

        Intent intent=new Intent(getApplicationContext(),SliderActivity.class);
        intent.putExtra("mauth",mauth.toString());
        startActivity(intent);


    }

    public void ForgotActivity(View view)
    {
        Intent intent=new Intent(getApplicationContext(),ForgotActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);




    }
}
